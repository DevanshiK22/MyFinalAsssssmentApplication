package com.example.myassssmentapplication


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myassssmentapplication.DashboardActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvResult = findViewById(R.id.tvResult)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                tvResult.text = getString(R.string.error_fill_fields)
                return@setOnClickListener
            }

            val request = LoginRequest(username, password)

            RetrofitClient.instance.login(request).enqueue(object : Callback<LoginResponse> {
                override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                    if (response.isSuccessful && response.body() != null) {
                        val keypass = response.body()!!.keypass
                        val intent = Intent(this@MainActivity, DashboardActivity::class.java)
                        intent.putExtra("KEYPASS", keypass)
                        startActivity(intent)
                        finish()
                    } else {
                        tvResult.text = getString(R.string.error_login_failed)
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    tvResult.text = getString(R.string.error_network, t.message)
                    Toast.makeText(this@MainActivity, getString(R.string.error_network, t.message), Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}
