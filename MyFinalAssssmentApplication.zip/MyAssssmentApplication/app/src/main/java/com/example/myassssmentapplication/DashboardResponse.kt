package com.example.myassssmentapplication

import com.example.myassssmentapplication.model.Entity

data class DashboardResponse(
    val entities: List<Entity>,
    val entityTotal: Int
)
