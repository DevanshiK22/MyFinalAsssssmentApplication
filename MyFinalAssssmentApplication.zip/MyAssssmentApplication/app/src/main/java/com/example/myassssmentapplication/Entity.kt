package com.example.myassssmentapplication.model

import java.io.Serializable

data class Entity(
    val properties: Map<String, String>
) : Serializable

