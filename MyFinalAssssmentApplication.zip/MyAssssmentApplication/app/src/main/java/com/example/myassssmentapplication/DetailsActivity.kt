package com.example.myassssmentapplication

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myassssmentapplication.MainActivity
import com.example.myassssmentapplication.R
import com.example.myassssmentapplication.model.Entity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // ✅ Use compatible getSerializableExtra without deprecation
        val entity: Entity? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("ENTITY", Entity::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("ENTITY") as? Entity
        }

        // ✅ Display all properties dynamically (no hardcoding)
        val textView = findViewById<TextView>(R.id.tvDetailContent)
        entity?.let {
            val displayText = it.properties.entries.joinToString("\n") { (_, value) -> value }
            textView.text = displayText
        }

        // ✅ Back button
        findViewById<Button>(R.id.btnBack)?.setOnClickListener {
            finish()
        }

        // ✅ Logout button
        findViewById<Button>(R.id.btnLogout)?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
