package com.example.myassssmentapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myassssmentapplication.model.Entity

class DashboardAdapter(
    private val entityList: List<Entity>,
    private val onItemClick: (Entity) -> Unit
) : RecyclerView.Adapter<DashboardAdapter.EntityViewHolder>() {

    inner class EntityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvMain: TextView = itemView.findViewById(R.id.tvMain)
        private val tvSub: TextView = itemView.findViewById(R.id.tvSub)

        fun bind(entity: Entity) {
            val props = entity.properties.entries.toList()

            // Dynamically display the first two property *values* (no labels, no hardcode)
            tvMain.text = props.getOrNull(0)?.value?.toString().orEmpty()
            tvSub.text = props.getOrNull(1)?.value?.toString().orEmpty()
        }

        init {
            itemView.setOnClickListener {
                var bindingAdapterPosition = 0
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(entityList[position])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntityViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_entity, parent, false)
        return EntityViewHolder(view)
    }

    override fun onBindViewHolder(holder: EntityViewHolder, position: Int) {
        holder.bind(entityList[position])
    }

    override fun getItemCount(): Int = entityList.size
}
