package com.example.myassssmentapplication

data class LoginRequest(
    val username: String,
    val password: String
)

